
//function testar(){
 //   alert("Seja bem vindo")
//}

//let Nome, Senha
//Nome = document.getElementById("Login").value
//Senha = document.getElementById("Senha").value

//function efetuarLogin(){
//    if(Nome == "admin" && Senha =="123"){
//        alert("Login efetuado")
//    }else{
 //       alert("Login falhou")
//    }
//}

let usuario = document.getElementById("inpNome")
let senha = document.getElementById("inpSenha")

function efetuarLogin(){
    console.log(usuario.value)
    console.log(senha.value)
    if(usuario.value == "Vitor" && senha.value == "1234"){
        alert("Seja bem vindo")
    }else{
        alert("Login incorreto")
    }
    usuario.value = ''
    senha.value = ''
}