let number, contador = 0

number = Number(prompt('Digite um número: '))

while(contador < number){
    contador ++
    alert('Fecha essa janela')
}