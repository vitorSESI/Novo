let nome = ""
let acumulador = ""

while(nome !== 'pare'){
    nome = prompt('Digite um nome, ou pare para sair ')
    nome = nome.toLowerCase(nome)
    if(nome !== "pare"){
        acumulador += nome + ', '
    }
}
alert(acumulador)