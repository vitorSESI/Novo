let contador = 0
contador 

while (true){
    if(contador < 0){
        
        console.log('Qualquer coisa')
        break;
    }else{
        console.log("não é menor");
        break;
    }
    
} 

