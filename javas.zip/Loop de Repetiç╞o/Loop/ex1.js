let contador = 0

while(contador < 10){
    console.log('foo ' + contador)
    contador++
}