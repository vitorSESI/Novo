let numero = 1;

while (numero <= 200 ) {
    if (numero % 2 === 1 && numero % 3 === 0 && numero >= 100 ) {
        console.log(numero);
    }
    numero++; // Incrementa o número dentro do loop
}
