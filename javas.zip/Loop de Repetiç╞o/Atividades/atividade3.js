let quantidade = Number(prompt("Quantos números você deseja digitar?"));
let soma = 0;
let contador = 0;

while (contador < quantidade) {
    let numero = Number(prompt(`Digite o número ${contador + 1}:`));
    soma += numero;
    contador++;
}

let media = soma / quantidade;

alert(`A média dos números digitados é: ${media}`);
