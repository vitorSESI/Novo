let soma = 0;

for (let i = 10; i <= 20; i++) {
    soma += i;
}

console.log(soma);
