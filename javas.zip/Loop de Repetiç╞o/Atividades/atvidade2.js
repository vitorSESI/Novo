let idade 

idade = Number(prompt('Digite uma idade: '))

while(idade < 18){
    alert(idade)
    idade = Number(prompt("Digite outra idade: "))
}if(idade >= 18){
    alert('Fim do Codigo')
}