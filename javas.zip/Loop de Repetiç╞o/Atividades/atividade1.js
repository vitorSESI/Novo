// Função para encontrar e exibir números pares entre 1 e 201
function mostrarNumerosPares() {
    // Loop de 1 a 201
    for (let i = 1; i <= 201; i++) {
        // Verifica se o número é par
        if (i % 2 === 0) {
            // Se for par, exibe na tela
            console.log(i);
        }
    }
}

// Chama a função para mostrar os números pares
mostrarNumerosPares();



let numero = 1
while(numero <= 201){
    if(numero % 2 == 0){
        console.log(numero)

    }
}   numero ++