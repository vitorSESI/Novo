alert('Oi, eu sou o exercicio.js, e estou muito feliz em ver você')

let nome
let sobrenome

nome = prompt('Qual é o seu nome? ')
sobrenome = prompt('Qual é o seu sobrenome? ')

let nomeCompleto
nomeCompleto = nome + sobrenome
alert('Seu nome é: ' + nomeCompleto)