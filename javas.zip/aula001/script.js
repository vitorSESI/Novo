//alert("Olá Mundo")
//alert("Eu estou estudando JavaScript")

//let resposta
//resposta = prompt('Ta curtindo fazer programas?')

//alert(resposta)
//alert('Fico feliz que sua resposta foi: ' + resposta)

let idade 
idade = 18
idade = idade + 1
console.log(idade)

idade = idade + 6
console.log(idade)

//idade = idade + '1'
//console.log('Somando 1: ' + idade)

idade++
console.log('Incrementando: ' + idade);

let metade
metade = idade / 2
console.log('Metadinha' + idade);

let idade7x1
idade7x1 = idade - 10
console.log('Idade no 7x1: ' + idade);

let dobro
dobro = idade * 2
console.log('Dobrado: ' + idade);



