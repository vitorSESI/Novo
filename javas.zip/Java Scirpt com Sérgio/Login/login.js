let userCorreto = "Vitor";
let passwordCorreto = "senha123";
let userResposta = "";
let passwordResposta = "";

while (true) {
    userResposta = prompt('Digite seu login: ');
    passwordResposta = prompt('Digite a sua senha: ');

    if (userResposta === userCorreto && passwordResposta === passwordCorreto) {
        alert('Login bem-sucedido!');
        break; // Sair do loop se as credenciais estiverem corretas
    } else {
        alert('Usuário ou senha incorretos. Por favor, tente novamente.');
    }
}