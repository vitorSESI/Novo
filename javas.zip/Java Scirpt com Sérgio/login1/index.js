let userName, password
userName = document.getElementById("Login").value
password = document.getElementById("Senha").value

function verificarLogin(){
    if(userName == "admin" && password =="123"){
        alert("Login efetuado")
    }else{
        alert("Login falhou")
    }
}