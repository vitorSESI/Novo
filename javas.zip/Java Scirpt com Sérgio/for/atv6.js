let num, soma = 0;

for(let i = 0; i < 5; i++){
    num = Number(prompt('Digite um número: '))
    if(num > 7){
        soma += num
    }
}
alert(`A soma dos números maiores que sete é: ${soma}`)