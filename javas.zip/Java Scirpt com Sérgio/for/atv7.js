let num = Number(prompt('Digite um número de 1-6: '))
switch(num){

    case 1:
    alert('UM')
    break

    case 2:
    alert('DOIS')
    break

    case 3:
    alert('TRÊS')
    break

    case 4:
    alert('QUATRO')
    break

    case 5:
    alert('CINCO')
    break

    case 6:
    alert('SEIS')
    break
    default:
        alert('Digite entre 1 e 6, seu caraio')
}
