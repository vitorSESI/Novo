let idade = Math.floor(Math.random()*90)+1
console.log(idade)

if(idade <18){
    console.log('Jovem')
}else if(idade>18 && idade<60){
    console.log('Adulto')
}else{
    console.log('Idoso')
}
