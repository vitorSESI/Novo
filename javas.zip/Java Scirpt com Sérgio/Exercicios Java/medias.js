let nota1 = Math.floor(Math.random() * 10) + 1;
let nota2 = Math.floor(Math.random() * 10) + 1;
let nota3 = Math.floor(Math.random() * 10) + 1;

console.log('Nota 1 é: ' + nota1);
console.log('Nota 2 é: ' + nota2);
console.log('Nota 3 é: ' + nota3);

let r = ('O resultado do aluno é: ');


let media = (nota1 + nota2 + nota3) / 3;
let mediaF = media.toFixed(1); // Correção: movido para antes do seu uso
console.log('A média deu: ' + mediaF);

if(media >= 7){
    console.log(r + 'Aprovado');
}else if(media < 7 && media >= 3){ // Pequena correção para incluir o caso em que a média é exatamente 3
    console.log(r + 'Recuperação');
}else{
    console.log(r + 'Reprovado'); // Correção de digitação
}
