let num;
idade = 24

if(idade >= 18){
    console.log("Maior de idade")
}else{
    console.log("Menor de idade")
}

if(idade % 2 == 0){
   console.log("Idadde Par")
}else{
    console.log("Idade Ímpar")
}

if(idade % 2 != 0){
console.log("Idadde Ímpar")
}else{
    console.log("Idade Par")
}


let anos
let sexo
anos = 19
cnh = true

if(idade>=18 && cnh == true){
    console.log("Pode dirigir")
}else{
    console.log("Não pode dirigir")
}

let idade1
idade1 = 16
tituloeleitor = false

if(idade1>=18 || tituloeleitor == true){
    console.log("Pode Votar")
}else{
    console.log("Não pode Votar")
}
a = 2

