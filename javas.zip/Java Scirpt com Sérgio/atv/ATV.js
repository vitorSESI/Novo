//let n1 = Math.floor(Math.random()*100) + 1;
//let n2 = Math.floor(Math.random()*100) + 1;


//if(n1 > n2){
//    console.log(n1 + " É maior que " + n2)
//}else{
//    console.log(n1 + " É menor que " + n2)
//}

let n1
let n2
n1 = prompt('Digite um número: ')
n2 = prompt('Digite outro número: ')

if(n1 > n2){
    console.log(n1 + " É maior que " + n2)
    alert(n1 + " É maior que " + n2)
}else{
   console.log(n1 + " É menor que " + n2)
   alert(n1 + " É menor que " + n2)
}
